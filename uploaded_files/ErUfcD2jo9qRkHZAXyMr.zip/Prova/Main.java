/* ****************************************************************************************
 * Faculdade de Engenharias Arquitetura e Urbanismo (FEAU) (Univap)
 * Curso: Engenharia da Computação - Data de Entrega: 17/04/2024
 * Autor: Lucas de oliveira lessa
 *
 * Turma: 9UNA Disciplina: Algoritmos Estrutura de Dados - II
 * Avaliação parcial referente ao 1 - Bimestre
 * Observação: Este main e testado atraves dos inputs do usuario no terminal
 *
 * Main.java
 * ***************************************************************************************/



import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Quantos Pacientes: ");
        int totalPacientes = Integer.parseInt(scanner.nextLine());

        Fila filaPacientes = new Fila();

        for (int i = 0; i < totalPacientes; i++) {
            System.out.println("Paciente " + (i + 1) + ":");

            ListaDuplamenteEncadeada listaPressoes = new ListaDuplamenteEncadeada();

            for (int j = 0; j < 7; j++) {
                System.out.print("Dia " + (j + 1) + ": ");
                String[] pressoes = scanner.nextLine().split(" ");
                for (String pressao : pressoes) {
                    listaPressoes.adiciona(Integer.parseInt(pressao));
                }
            }

            filaPacientes.insere(listaPressoes);
        }

        System.out.println("\nSaídas:");

        double menorVariancia = Double.MAX_VALUE;
        byte pacienteMaiorRegularidade = -1;

        for (byte i = 0; i < totalPacientes; i++) {
            ListaDuplamenteEncadeada listaPressoes = (ListaDuplamenteEncadeada) filaPacientes.pega();
            double media = CalculadoraPressaoArterial.calcularMedia(listaPressoes);
            double desvioPadrao = CalculadoraPressaoArterial.calcularDesvioPadrao(listaPressoes, media);
            double variancia = CalculadoraPressaoArterial.calcularVariancia(listaPressoes, media);

            System.out.println("Paciente " + (i + 1) + ":");
            System.out.println("Média: " + String.format("%.2f", media).replace(".", ","));
            System.out.println("Desvio Padrão: " + String.format("%.2f", desvioPadrao).replace(".", ","));
            System.out.println("Variância: " + String.format("%.2f", variancia).replace(".", ","));
            System.out.println();

            if (variancia < menorVariancia) {
                menorVariancia = variancia;
                pacienteMaiorRegularidade = i;
            }
        }

        System.out.println("O paciente " + (pacienteMaiorRegularidade + 1) + ", apresenta maior regularidade na pressão arterial.");

        scanner.close();
    }
}
