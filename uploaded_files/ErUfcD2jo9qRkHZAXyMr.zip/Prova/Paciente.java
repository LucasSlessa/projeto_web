class Paciente {
    private byte ID; // Identificação do Paciente
    private int press_manha; // Pressão Arterial
    private int press_tarde; // Pressão Arterial
    private int press_noite; // Pressão Arterial

    public Paciente(byte ID, int press_manha, int press_tarde, int press_noite) {
        this.ID = ID;
        this.press_manha = press_manha;
        this.press_tarde = press_tarde;
        this.press_noite = press_noite;
    }

    public byte getID() {
        return ID;
    }

    public int getPress_manha() {
        return press_manha;
    }

    public int getPress_tarde() {
        return press_tarde;
    }

    public int getPress_noite() {
        return press_noite;
    }

    @Override
    public String toString() {
        return "Paciente{" +
                "ID=" + ID +
                ", press_manha=" + press_manha +
                ", press_tarde=" + press_tarde +
                ", press_noite=" + press_noite +
                '}';
    }
}

