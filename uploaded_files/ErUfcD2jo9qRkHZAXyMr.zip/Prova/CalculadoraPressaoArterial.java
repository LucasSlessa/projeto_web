public class CalculadoraPressaoArterial {

    public static double calcularMedia(ListaDuplamenteEncadeada lista) {
        int total = lista.tamanho();
        int soma = 0;
        for (int i = 0; i < total; i++) {
            soma += (int) lista.pega(i);
        }
        return soma / (double) total;
    }

    public static double calcularDesvioPadrao(ListaDuplamenteEncadeada lista, double media) {
        int total = lista.tamanho();
        double somaDesvioQuadrado = 0;
        for (int i = 0; i < total; i++) {
            double desvio = (int) lista.pega(i) - media;
            somaDesvioQuadrado += desvio * desvio;
        }
        double variancia = somaDesvioQuadrado / total;
        return Math.sqrt(variancia);
    }

    public static double calcularVariancia(ListaDuplamenteEncadeada lista, double media) {
        int total = lista.tamanho();
        double somaDesvioQuadrado = 0;
        for (int i = 0; i < total; i++) {
            double desvio = (int) lista.pega(i) - media;
            somaDesvioQuadrado += desvio * desvio;
        }
        return somaDesvioQuadrado / total;
    }
}
