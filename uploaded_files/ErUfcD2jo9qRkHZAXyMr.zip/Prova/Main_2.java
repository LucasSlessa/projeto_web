/* ****************************************************************************************
 * Faculdade de Engenharias Arquitetura e Urbanismo (FEAU) (Univap)
 * Curso: Engenharia da Computação - Data de Entrega: 17/04/2024
 * Autor: Lucas de oliveira lessa
 *
 * Turma: 9UNA Disciplina: Algoritmos Estrutura de Dados - II
 * Avaliação parcial referente ao 1 - Bimestre
 * Observação: Este main e testado atraves do arquivo input.txt !!!importante
 *
 * Main_2.java
 * ***************************************************************************************/




import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main_2 {

    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(new File("input.txt"));

            int totalPacientes = Integer.parseInt(scanner.nextLine());

            Fila filaPacientes = new Fila();

            for (int i = 0; i < totalPacientes; i++) {
                ListaDuplamenteEncadeada listaPressoes = new ListaDuplamenteEncadeada();

                for (int j = 0; j < 7; j++) {
                    String[] pressoes = scanner.nextLine().split(" ");
                    for (String pressao : pressoes) {
                        listaPressoes.adiciona(Integer.parseInt(pressao));
                    }
                }

                filaPacientes.insere(listaPressoes);
            }

            System.out.println("\nSaídas:");

            double menorVariancia = Double.MAX_VALUE;
            byte pacienteMaiorRegularidade = -1;

            for (byte i = 0; i < totalPacientes; i++) {
                ListaDuplamenteEncadeada listaPressoes = (ListaDuplamenteEncadeada) filaPacientes.pega();
                double media = CalculadoraPressaoArterial.calcularMedia(listaPressoes);
                double desvioPadrao = CalculadoraPressaoArterial.calcularDesvioPadrao(listaPressoes, media);
                double variancia = CalculadoraPressaoArterial.calcularVariancia(listaPressoes, media);

                System.out.println("Paciente " + (i + 1) + ":");
                System.out.println("Média: " + String.format("%.2f", media).replace(".", ","));
                System.out.println("Desvio Padrão: " + String.format("%.2f", desvioPadrao).replace(".", ","));
                System.out.println("Variância: " + String.format("%.2f", variancia).replace(".", ","));
                System.out.println();

                if (variancia < menorVariancia) {
                    menorVariancia = variancia;
                    pacienteMaiorRegularidade = i;
                }
            }

            System.out.println("O paciente " + (pacienteMaiorRegularidade + 1) + ", apresenta maior regularidade na pressão arterial.");

            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Arquivo não encontrado.");
        }
    }
}
